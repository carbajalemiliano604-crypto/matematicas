import type { Figure } from "@/lib/quiz";

type Variant = "full" | "mini";

const CHART = [
  "var(--color-chart-1)",
  "var(--color-chart-2)",
  "var(--color-chart-3)",
  "var(--color-chart-4)",
  "var(--color-chart-5)",
];

const CHIP = [
  "bg-barras text-barras-ink",
  "bg-circular text-circular-ink",
  "bg-poligono text-poligono-ink",
  "bg-media text-media-ink",
  "bg-moda text-moda-ink",
  "bg-mediana text-mediana-ink",
  "bg-rango text-rango-ink",
];

function niceTop(max: number): number {
  if (max <= 4) return 4;
  if (max <= 5) return 5;
  if (max <= 8) return 8;
  if (max <= 10) return 10;
  if (max <= 12) return 12;
  if (max <= 16) return 16;
  return Math.ceil(max / 5) * 5;
}

function ticksFor(top: number): number[] {
  const step = top <= 6 ? 1 : top <= 12 ? 2 : top / 4;
  const ticks: number[] = [];
  for (let value = 0; value <= top + 0.001; value += step) ticks.push(Math.round(value));
  return [...new Set(ticks)];
}

function Categorical({
  values,
  labels,
  variant,
  mode,
}: {
  values: number[];
  labels: string[];
  variant: Variant;
  mode: "bars" | "polygon";
}) {
  const full = variant === "full";
  const w = full ? 320 : 168;
  const h = full ? 228 : 124;
  const left = full ? 34 : 16;
  const right = 10;
  const top = full ? 26 : 12;
  const bottom = full ? 32 : 22;
  const base = h - bottom;
  const plotW = w - left - right;
  const plotH = base - top;
  const topValue = niceTop(Math.max(...values, 1));
  const ticks = ticksFor(topValue);
  const slot = plotW / values.length;
  const yOf = (value: number) => base - (value / topValue) * plotH;

  const points = values.map((value, index) => {
    const x = left + index * slot + slot / 2;
    return { x, y: yOf(value), value, label: labels[index] ?? "" };
  });
  const line = points.map((point, index) => `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`).join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-auto w-full" aria-hidden="true" style={{ fontFamily: "Outfit, sans-serif" }}>
      {ticks.map((tick) => {
        const y = yOf(tick);
        return (
          <g key={tick}>
            <line x1={left} y1={y} x2={w - right} y2={y} stroke="var(--color-line)" strokeWidth="1" />
            {full && (
              <text x={left - 6} y={y + 4} textAnchor="end" fontSize="11" fill="var(--color-ink)">
                {tick}
              </text>
            )}
          </g>
        );
      })}
      <line x1={left} y1={top} x2={left} y2={base} stroke="var(--color-ink)" strokeWidth="1.6" />
      <line x1={left} y1={base} x2={w - right} y2={base} stroke="var(--color-ink)" strokeWidth="1.6" />
      {mode === "bars" &&
        values.map((value, index) => {
          const barW = Math.min(full ? 36 : 18, slot - (full ? 16 : 8));
          const x = left + index * slot + (slot - barW) / 2;
          const y = yOf(value);
          return (
            <rect key={labels[index] ?? index} x={x} y={y} width={barW} height={Math.max(0, base - y)} rx={full ? 6 : 4} fill={CHART[index % CHART.length]} />
          );
        })}
      {mode === "polygon" && (
        <g>
          <path d={line} fill="none" stroke="var(--color-accent)" strokeWidth={full ? 3 : 2.2} strokeLinejoin="round" strokeLinecap="round" />
          {points.map((point, index) => (
            <g key={point.label || index}>
              <circle cx={point.x} cy={point.y} r={full ? 5.5 : 3.5} fill={CHART[index % CHART.length]} stroke="var(--color-ink)" strokeWidth="1.4" />
              {full && (
                <text x={point.x} y={point.y - 10} textAnchor="middle" fontSize="12" fontWeight="700" fill="var(--color-ink)">
                  {point.value}
                </text>
              )}
            </g>
          ))}
        </g>
      )}
      {points.map((point) => (
        <text key={`l-${point.label}`} x={point.x} y={base + (full ? 18 : 14)} textAnchor="middle" fontSize={full ? 12 : 9} fill="var(--color-ink)">
          {point.label}
        </text>
      ))}
    </svg>
  );
}

function pieSlice(cx: number, cy: number, r: number, start: number, end: number): string {
  const large = end - start > Math.PI ? 1 : 0;
  const x0 = cx + r * Math.cos(start);
  const y0 = cy + r * Math.sin(start);
  const x1 = cx + r * Math.cos(end);
  const y1 = cy + r * Math.sin(end);
  return `M ${cx} ${cy} L ${x0} ${y0} A ${r} ${r} 0 ${large} 1 ${x1} ${y1} Z`;
}

function PieGraph({ slices, variant }: { slices: { label: string; value: number }[]; variant: Variant }) {
  const full = variant === "full";
  const w = full ? 340 : 160;
  const h = full ? 210 : 120;
  const cx = full ? 92 : 80;
  const cy = full ? 108 : 60;
  const r = full ? 72 : 46;
  const total = slices.reduce((sum, slice) => sum + slice.value, 0) || 1;
  let angle = -Math.PI / 2;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-auto w-full" aria-hidden="true" style={{ fontFamily: "Outfit, sans-serif" }}>
      {slices.map((slice, index) => {
        const next = angle + (slice.value / total) * Math.PI * 2;
        const d = pieSlice(cx, cy, r, angle, next - 0.001);
        angle = next;
        return <path key={slice.label} d={d} fill={CHART[index % CHART.length]} stroke="var(--color-well)" strokeWidth="2" />;
      })}
      {full &&
        slices.map((slice, index) => (
          <g key={`key-${slice.label}`}>
            <rect x="188" y={28 + index * 36} width="16" height="16" rx="4" fill={CHART[index % CHART.length]} />
            <text x="212" y={41 + index * 36} fontSize="14" fill="var(--color-ink)">
              {slice.label}
            </text>
            <text x="328" y={41 + index * 36} fontSize="14" fontWeight="700" textAnchor="end" fill="var(--color-ink)">
              {slice.value}
            </text>
          </g>
        ))}
    </svg>
  );
}

function Chips({ values }: { values: number[] }) {
  return (
    <span className="flex flex-wrap justify-center gap-2 px-2 py-3">
      {values.map((value, index) => (
        <span
          key={`${value}-${index}`}
          className={`flex size-12 items-center justify-center rounded-2xl font-display text-2xl ${CHIP[index % CHIP.length]}`}
        >
          {value}
        </span>
      ))}
    </span>
  );
}

function TableFig({ headers, rows }: { headers: [string, string]; rows: [string, string][] }) {
  return (
    <table className="w-full border-collapse text-left text-sm text-ink">
      <thead>
        <tr className="text-accent">
          <th className="px-3 py-2 font-semibold">{headers[0]}</th>
          <th className="px-3 py-2 text-right font-semibold">{headers[1]}</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr key={row[0]} className="border-t border-line">
            <td className="px-3 py-2 font-medium">{row[0]}</td>
            <td className="px-3 py-2 text-right font-semibold tabular-nums">{row[1]}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function GraphFigure({ figure, variant = "full" }: { figure: Figure; variant?: Variant }) {
  if (figure.kind === "bars") {
    return <Categorical values={figure.values} labels={figure.labels} variant={variant} mode="bars" />;
  }
  if (figure.kind === "polygon") {
    return <Categorical values={figure.values} labels={figure.labels} variant={variant} mode="polygon" />;
  }
  if (figure.kind === "pie") return <PieGraph slices={figure.slices} variant={variant} />;
  if (figure.kind === "chips") return <Chips values={figure.values} />;
  return <TableFig headers={figure.headers} rows={figure.rows} />;
}
