import { useEffect, useState } from "react";
import {
  AlignCenter,
  ArrowLeftRight,
  ArrowRight,
  BarChart3,
  LineChart,
  PieChart,
  RotateCcw,
  Sigma,
  Star,
  Trophy,
} from "lucide-react";
import { GraphFigure } from "@/components/graph-figure";
import {
  QUIZ_LENGTH,
  TOPIC_IDS,
  TOPIC_LENGTH,
  TONES,
  TOPICS,
  buildQuiz,
  buildTopicQuiz,
  memeFor,
  scoreQuiz,
  topicById,
  type Question,
  type TopicId,
} from "@/lib/quiz";

const STORAGE_KEY = "grafiquiz-v2";

const ICONS = {
  barras: BarChart3,
  circular: PieChart,
  poligono: LineChart,
  rango: ArrowLeftRight,
  media: Sigma,
  moda: Star,
  mediana: AlignCenter,
} as const;

type Save = { name: string; best: number };

function loadSave(): Save | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Save>;
    if (typeof parsed.best !== "number") return null;
    return { name: typeof parsed.name === "string" ? parsed.name : "", best: parsed.best };
  } catch {
    return null;
  }
}

function storeSave(save: Save) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
}

export function QuizApp() {
  const [name, setName] = useState("");
  const [best, setBest] = useState<number | null>(null);
  const [ready, setReady] = useState(false);
  const [phase, setPhase] = useState<"home" | "play" | "done">("home");
  const [mix, setMix] = useState(true);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [record, setRecord] = useState(false);

  useEffect(() => {
    const saved = loadSave();
    if (saved) {
      setBest(saved.best);
      setName(saved.name);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [phase, index]);

  function start(topic?: TopicId) {
    const clean = name.trim().slice(0, 24);
    setName(clean);
    const nextMix = !topic;
    setMix(nextMix);
    setQuestions(topic ? buildTopicQuiz(topic) : buildQuiz());
    setIndex(0);
    setPicked(null);
    setConfirmed(false);
    setAnswers({});
    setRecord(false);
    setPhase("play");
    const previous = loadSave();
    if (previous) storeSave({ name: clean, best: previous.best });
  }

  function confirm() {
    const question = questions[index];
    if (!question || !picked) return;
    setAnswers((current) => ({ ...current, [question.id]: picked }));
    setConfirmed(true);
  }

  function finish(nextAnswers: Record<string, string>) {
    const score = scoreQuiz(questions, nextAnswers);
    if (mix) {
      const improved = best !== null && score > best;
      const nextBest = Math.max(best ?? 0, score);
      setBest(nextBest);
      setRecord(improved);
      storeSave({ name: name.trim(), best: nextBest });
    }
    setPhase("done");
  }

  function next() {
    if (index + 1 >= questions.length) {
      finish(answers);
      return;
    }
    setIndex((current) => current + 1);
    setPicked(null);
    setConfirmed(false);
  }

  const score = scoreQuiz(questions, answers);
  const meme = memeFor(score, questions.length);
  const missed = questions.filter((question) => answers[question.id] !== question.correctId);

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 py-8 sm:px-6 sm:py-12">
      <header className="mb-6 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setPhase("home")}
          className="flex items-center gap-2 rounded-full bg-sheet px-3 py-2 text-left text-ink ring-1 ring-line"
        >
          <span className="flex size-9 items-center justify-center rounded-full bg-accent text-accent-ink">
            <LineChart size={18} aria-hidden="true" />
          </span>
          <span>
            <span className="block font-display text-lg leading-none">GrafiQuiz</span>
            <span className="text-xs text-muted">1º de secundaria</span>
          </span>
        </button>
        {ready && best !== null && best > 0 && (
          <p className="rounded-full bg-sheet px-3 py-2 text-sm font-semibold text-ink tabular-nums ring-1 ring-line">
            Mejor {best}/{QUIZ_LENGTH}
          </p>
        )}
      </header>

      {phase === "home" && (
        <HomeScreen name={name} best={ready ? best : null} onName={setName} onStart={start} />
      )}

      {phase === "play" && questions[index] && (
        <PlayScreen
          question={questions[index]}
          index={index}
          total={questions.length}
          picked={picked}
          confirmed={confirmed}
          onPick={setPicked}
          onConfirm={confirm}
          onNext={next}
        />
      )}

      {phase === "done" && (
        <ResultScreen
          name={name.trim()}
          score={score}
          total={questions.length}
          mix={mix}
          meme={meme}
          record={record}
          missed={missed}
          answers={answers}
          onAgain={() => start(mix ? undefined : questions[0]?.topic)}
          onHome={() => setPhase("home")}
        />
      )}
    </main>
  );
}

function HomeScreen({
  name,
  best,
  onName,
  onStart,
}: {
  name: string;
  best: number | null;
  onName: (value: string) => void;
  onStart: (topic?: TopicId) => void;
}) {
  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-3xl bg-accent p-6 text-accent-ink shadow-sm sm:p-8">
        <p className="text-sm font-semibold tracking-wide uppercase">Siete temas, siete colores</p>
        <h1 className="mt-2 font-display text-4xl leading-tight sm:text-5xl">Gráficas y promedios</h1>
        <p className="mt-3 max-w-prose">
          Preguntas de 1º: barras, gráfica circular, polígono de frecuencias, rango, media, moda y
          mediana. Cada intento trae datos nuevos.
        </p>
        <form
          className="mt-6 flex flex-col gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            onStart();
          }}
        >
          <label className="text-sm font-semibold" htmlFor="student-name">
            Tu nombre, si quieres
          </label>
          <input
            id="student-name"
            value={name}
            maxLength={24}
            autoComplete="nickname"
            placeholder="Ejemplo: Ana"
            onChange={(event) => onName(event.target.value)}
            className="min-h-12 w-full rounded-2xl border-2 border-paper bg-paper px-4 text-ink placeholder:text-muted"
          />
          <button
            type="submit"
            className="mt-1 inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-paper px-6 font-semibold text-ink"
          >
            Cuestionario de los {TOPIC_IDS.length} temas
            <ArrowRight size={18} aria-hidden="true" />
          </button>
          {best !== null && (
            <p className="text-sm">
              Tu mejor marca del cuestionario completo, en este aparato:{" "}
              <span className="font-semibold tabular-nums">
                {best}/{QUIZ_LENGTH}
              </span>
            </p>
          )}
        </form>
      </section>

      <section>
        <h2 className="font-display text-2xl text-ink">Elige un tema</h2>
        <p className="mt-1 text-sm text-muted">
          {TOPIC_LENGTH} preguntas del color que pulses. Sirve para repasar uno solo.
        </p>
        <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {TOPICS.map((topic) => {
            const tone = TONES[topic.id];
            const Icon = ICONS[topic.id];
            return (
              <li key={topic.id}>
                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => onStart(topic.id)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault();
                      onStart(topic.id);
                    }
                  }}
                  className={`flex h-full flex-col rounded-3xl p-4 text-left ${tone.band}`}
                >
                  <span className="flex items-center gap-2">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-paper text-ink">
                      <Icon size={18} aria-hidden="true" />
                    </span>
                    <span className="font-display text-2xl leading-tight">{topic.title}</span>
                  </span>
                  <span className="mt-3 block rounded-2xl bg-well p-1 text-ink">
                    <GraphFigure figure={topic.figure} variant="mini" />
                  </span>
                  <span className="mt-3 text-sm">{topic.body}</span>
                  <span className="mt-3 text-sm font-semibold">Practicar este tema</span>
                </div>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}

function PlayScreen({
  question,
  index,
  total,
  picked,
  confirmed,
  onPick,
  onConfirm,
  onNext,
}: {
  question: Question;
  index: number;
  total: number;
  picked: string | null;
  confirmed: boolean;
  onPick: (id: string) => void;
  onConfirm: () => void;
  onNext: () => void;
}) {
  const tone = TONES[question.topic];
  const topic = topicById(question.topic);
  const visual = question.options.some((option) => option.figure);
  const correct = picked === question.correctId;

  return (
    <section className={`rounded-3xl p-5 shadow-sm sm:p-7 ${tone.band}`}>
      <div className="flex items-center justify-between gap-3 text-sm">
        <p className="font-semibold tabular-nums">
          Pregunta {index + 1} de {total}
        </p>
        <p className="rounded-full bg-paper px-3 py-1 font-semibold text-ink">{topic.title}</p>
      </div>
      <div className={`mt-3 h-2 overflow-hidden rounded-full ${tone.track}`} aria-hidden="true">
        <div className={`h-full rounded-full ${tone.fill}`} style={{ width: `${(index / total) * 100}%` }} />
      </div>

      <h2 className="mt-5 font-display text-2xl leading-snug sm:text-3xl">{question.prompt}</h2>
      {question.srFigure && <p className="sr-only">{question.srFigure}</p>}
      {question.figure && (
        <div className="mx-auto mt-4 max-w-md rounded-2xl bg-well p-2 text-ink">
          <GraphFigure figure={question.figure} />
        </div>
      )}

      <div className={visual ? "mt-5 grid grid-cols-2 gap-3" : "mt-5 flex flex-col gap-3"} role="group" aria-label="Opciones">
        {question.options.map((option) => {
          const isPicked = picked === option.id;
          const showCorrect = confirmed && option.id === question.correctId;
          const showWrong = confirmed && isPicked && option.id !== question.correctId;
          return (
            <button
              key={option.id}
              type="button"
              disabled={confirmed}
              aria-pressed={isPicked}
              onClick={() => onPick(option.id)}
              className={[
                "min-h-12 rounded-2xl border-2 px-3 py-3 text-left text-ink",
                visual ? "flex flex-col gap-2" : "",
                showCorrect
                  ? "border-good bg-good-soft"
                  : showWrong
                    ? "border-bad bg-bad-soft"
                    : isPicked
                      ? "border-accent bg-sheet"
                      : "border-transparent bg-paper",
                confirmed && !showCorrect && !showWrong ? "opacity-55" : "",
              ].join(" ")}
            >
              {option.figure && (
                <span className="block rounded-xl bg-well p-1">
                  <GraphFigure figure={option.figure} variant="mini" />
                </span>
              )}
              <span className={option.figure ? "text-sm font-medium" : "font-medium"}>{option.label}</span>
            </button>
          );
        })}
      </div>

      {confirmed && (
        <div className="mt-4 rounded-2xl bg-paper px-4 py-3 text-sm text-ink">
          <p className={correct ? "font-semibold text-good" : "font-semibold text-bad"}>
            {correct ? "Correcto" : "Casi"}
          </p>
          <p className="mt-1">{question.explain}</p>
        </div>
      )}

      <div className="mt-5">
        {!confirmed ? (
          <button
            type="button"
            disabled={!picked}
            onClick={onConfirm}
            className="inline-flex min-h-12 w-full items-center justify-center rounded-full bg-paper px-6 font-semibold text-ink disabled:opacity-40"
          >
            Confirmar respuesta
          </button>
        ) : (
          <button
            type="button"
            onClick={onNext}
            className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-paper px-6 font-semibold text-ink"
          >
            {index + 1 === total ? "Ver mi puntaje" : "Siguiente"}
            <ArrowRight size={18} aria-hidden="true" />
          </button>
        )}
      </div>
    </section>
  );
}

function ResultScreen({
  name,
  score,
  total,
  mix,
  meme,
  record,
  missed,
  answers,
  onAgain,
  onHome,
}: {
  name: string;
  score: number;
  total: number;
  mix: boolean;
  meme: ReturnType<typeof memeFor>;
  record: boolean;
  missed: Question[];
  answers: Record<string, string>;
  onAgain: () => void;
  onHome: () => void;
}) {
  const percent = total === 0 ? 0 : Math.round((score / total) * 100);
  return (
    <section className="flex flex-col gap-5">
      <div className="rounded-3xl bg-sheet p-5 text-ink ring-1 ring-line sm:p-7">
        <p className="text-sm font-semibold text-accent">Resultado</p>
        <h2 className="mt-1 font-display text-3xl">
          {name ? `${name}, ${meme.title.toLowerCase()}` : meme.title}
        </h2>
        <p className="mt-3 font-display text-6xl text-accent tabular-nums leading-none">
          {score}
          <span className="text-3xl text-muted">/{total}</span>
        </p>
        <p className="mt-2 text-muted tabular-nums">{percent}% de aciertos</p>
        {record && score > 0 && (
          <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-good-soft px-3 py-1 text-sm font-semibold text-good">
            <Trophy size={16} aria-hidden="true" />
            Nueva mejor marca
          </p>
        )}
        <img
          src={meme.image}
          alt={meme.alt}
          width={960}
          height={960}
          className="mt-5 aspect-square w-full rounded-3xl object-cover"
        />
        <p className="mt-4 text-lg">{meme.line}</p>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <button
            type="button"
            onClick={onAgain}
            className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-full bg-accent px-5 font-semibold text-accent-ink"
          >
            <RotateCcw size={18} aria-hidden="true" />
            {mix ? "Otro cuestionario" : "Repetir este tema"}
          </button>
          <button
            type="button"
            onClick={onHome}
            className="inline-flex min-h-12 flex-1 items-center justify-center rounded-full bg-paper px-5 font-semibold text-ink ring-1 ring-line"
          >
            Elegir tema
          </button>
        </div>
      </div>

      <div className="rounded-3xl bg-sheet p-5 text-ink ring-1 ring-line sm:p-7">
        <h3 className="font-display text-2xl">{missed.length === 0 ? "No fallaste ninguna" : "Para repasar"}</h3>
        {missed.length === 0 ? (
          <p className="mt-2 text-muted">Estas ideas quedaron claras. Si quieres, mezcla otro intento.</p>
        ) : (
          <ul className="mt-4 flex flex-col gap-4">
            {missed.map((question) => {
              const chosen = question.options.find((option) => option.id === answers[question.id]);
              const right = question.options.find((option) => option.id === question.correctId);
              const tone = TONES[question.topic];
              return (
                <li key={question.id} className="border-t border-line pt-4 first:border-t-0 first:pt-0">
                  <p className={`inline-flex rounded-full px-2 py-0.5 text-xs font-semibold ${tone.band}`}>
                    {topicById(question.topic).title}
                  </p>
                  <p className="mt-2 font-medium">{question.prompt}</p>
                  <p className="mt-2 text-sm text-bad">Elegiste: {chosen?.label ?? "sin respuesta"}</p>
                  <p className="text-sm text-good">Correcta: {right?.label}</p>
                  <p className="mt-1 text-sm text-muted">{question.explain}</p>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}
