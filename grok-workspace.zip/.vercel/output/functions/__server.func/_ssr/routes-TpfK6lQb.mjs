import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, c as ChartLine, d as AlignCenter, i as Sigma, l as ArrowRight, o as ChartPie, r as Star, s as ChartColumn, t as Trophy, u as ArrowLeftRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-TpfK6lQb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHART = [
	"var(--color-chart-1)",
	"var(--color-chart-2)",
	"var(--color-chart-3)",
	"var(--color-chart-4)",
	"var(--color-chart-5)"
];
var CHIP = [
	"bg-barras text-barras-ink",
	"bg-circular text-circular-ink",
	"bg-poligono text-poligono-ink",
	"bg-media text-media-ink",
	"bg-moda text-moda-ink",
	"bg-mediana text-mediana-ink",
	"bg-rango text-rango-ink"
];
function niceTop(max) {
	if (max <= 4) return 4;
	if (max <= 5) return 5;
	if (max <= 8) return 8;
	if (max <= 10) return 10;
	if (max <= 12) return 12;
	if (max <= 16) return 16;
	return Math.ceil(max / 5) * 5;
}
function ticksFor(top) {
	const step = top <= 6 ? 1 : top <= 12 ? 2 : top / 4;
	const ticks = [];
	for (let value = 0; value <= top + .001; value += step) ticks.push(Math.round(value));
	return [...new Set(ticks)];
}
function Categorical({ values, labels, variant, mode }) {
	const full = variant === "full";
	const w = full ? 320 : 168;
	const h = full ? 228 : 124;
	const left = full ? 34 : 16;
	const right = 10;
	const top = full ? 26 : 12;
	const base = h - (full ? 32 : 22);
	const plotW = w - left - right;
	const plotH = base - top;
	const topValue = niceTop(Math.max(...values, 1));
	const ticks = ticksFor(topValue);
	const slot = plotW / values.length;
	const yOf = (value) => base - value / topValue * plotH;
	const points = values.map((value, index) => {
		return {
			x: left + index * slot + slot / 2,
			y: yOf(value),
			value,
			label: labels[index] ?? ""
		};
	});
	const line = points.map((point, index) => `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-auto w-full",
		"aria-hidden": "true",
		style: { fontFamily: "Outfit, sans-serif" },
		children: [
			ticks.map((tick) => {
				const y = yOf(tick);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: left,
					y1: y,
					x2: w - right,
					y2: y,
					stroke: "var(--color-line)",
					strokeWidth: "1"
				}), full && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: left - 6,
					y: y + 4,
					textAnchor: "end",
					fontSize: "11",
					fill: "var(--color-ink)",
					children: tick
				})] }, tick);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: left,
				y1: top,
				x2: left,
				y2: base,
				stroke: "var(--color-ink)",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: left,
				y1: base,
				x2: w - right,
				y2: base,
				stroke: "var(--color-ink)",
				strokeWidth: "1.6"
			}),
			mode === "bars" && values.map((value, index) => {
				const barW = Math.min(full ? 36 : 18, slot - (full ? 16 : 8));
				const x = left + index * slot + (slot - barW) / 2;
				const y = yOf(value);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x,
					y,
					width: barW,
					height: Math.max(0, base - y),
					rx: full ? 6 : 4,
					fill: CHART[index % CHART.length]
				}, labels[index] ?? index);
			}),
			mode === "polygon" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: line,
				fill: "none",
				stroke: "var(--color-accent)",
				strokeWidth: full ? 3 : 2.2,
				strokeLinejoin: "round",
				strokeLinecap: "round"
			}), points.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: point.x,
				cy: point.y,
				r: full ? 5.5 : 3.5,
				fill: CHART[index % CHART.length],
				stroke: "var(--color-ink)",
				strokeWidth: "1.4"
			}), full && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: point.x,
				y: point.y - 10,
				textAnchor: "middle",
				fontSize: "12",
				fontWeight: "700",
				fill: "var(--color-ink)",
				children: point.value
			})] }, point.label || index))] }),
			points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: point.x,
				y: base + (full ? 18 : 14),
				textAnchor: "middle",
				fontSize: full ? 12 : 9,
				fill: "var(--color-ink)",
				children: point.label
			}, `l-${point.label}`))
		]
	});
}
function pieSlice(cx, cy, r, start, end) {
	const large = end - start > Math.PI ? 1 : 0;
	return `M ${cx} ${cy} L ${cx + r * Math.cos(start)} ${cy + r * Math.sin(start)} A ${r} ${r} 0 ${large} 1 ${cx + r * Math.cos(end)} ${cy + r * Math.sin(end)} Z`;
}
function PieGraph({ slices, variant }) {
	const full = variant === "full";
	const w = full ? 340 : 160;
	const h = full ? 210 : 120;
	const cx = full ? 92 : 80;
	const cy = full ? 108 : 60;
	const r = full ? 72 : 46;
	const total = slices.reduce((sum, slice) => sum + slice.value, 0) || 1;
	let angle = -Math.PI / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "h-auto w-full",
		"aria-hidden": "true",
		style: { fontFamily: "Outfit, sans-serif" },
		children: [slices.map((slice, index) => {
			const next = angle + slice.value / total * Math.PI * 2;
			const d = pieSlice(cx, cy, r, angle, next - .001);
			angle = next;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d,
				fill: CHART[index % CHART.length],
				stroke: "var(--color-well)",
				strokeWidth: "2"
			}, slice.label);
		}), full && slices.map((slice, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "188",
				y: 28 + index * 36,
				width: "16",
				height: "16",
				rx: "4",
				fill: CHART[index % CHART.length]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "212",
				y: 41 + index * 36,
				fontSize: "14",
				fill: "var(--color-ink)",
				children: slice.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "328",
				y: 41 + index * 36,
				fontSize: "14",
				fontWeight: "700",
				textAnchor: "end",
				fill: "var(--color-ink)",
				children: slice.value
			})
		] }, `key-${slice.label}`))]
	});
}
function Chips({ values }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex flex-wrap justify-center gap-2 px-2 py-3",
		children: values.map((value, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `flex size-12 items-center justify-center rounded-2xl font-display text-2xl ${CHIP[index % CHIP.length]}`,
			children: value
		}, `${value}-${index}`))
	});
}
function TableFig({ headers, rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full border-collapse text-left text-sm text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "text-accent",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold",
				children: headers[0]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 text-right font-semibold",
				children: headers[1]
			})]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-t border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2 font-medium",
				children: row[0]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2 text-right font-semibold tabular-nums",
				children: row[1]
			})]
		}, row[0])) })]
	});
}
function GraphFigure({ figure, variant = "full" }) {
	if (figure.kind === "bars") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Categorical, {
		values: figure.values,
		labels: figure.labels,
		variant,
		mode: "bars"
	});
	if (figure.kind === "polygon") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Categorical, {
		values: figure.values,
		labels: figure.labels,
		variant,
		mode: "polygon"
	});
	if (figure.kind === "pie") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieGraph, {
		slices: figure.slices,
		variant
	});
	if (figure.kind === "chips") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, { values: figure.values });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFig, {
		headers: figure.headers,
		rows: figure.rows
	});
}
var TOPIC_IDS = [
	"barras",
	"circular",
	"poligono",
	"rango",
	"media",
	"moda",
	"mediana"
];
var TONES = {
	barras: {
		band: "bg-barras text-barras-ink",
		border: "border-barras",
		fill: "bg-barras-ink",
		track: "bg-barras-ink/25"
	},
	circular: {
		band: "bg-circular text-circular-ink",
		border: "border-circular",
		fill: "bg-circular-ink",
		track: "bg-circular-ink/25"
	},
	poligono: {
		band: "bg-poligono text-poligono-ink",
		border: "border-poligono",
		fill: "bg-poligono-ink",
		track: "bg-poligono-ink/25"
	},
	rango: {
		band: "bg-rango text-rango-ink",
		border: "border-rango",
		fill: "bg-rango-ink",
		track: "bg-rango-ink/25"
	},
	media: {
		band: "bg-media text-media-ink",
		border: "border-media",
		fill: "bg-media-ink",
		track: "bg-media-ink/25"
	},
	moda: {
		band: "bg-moda text-moda-ink",
		border: "border-moda",
		fill: "bg-moda-ink",
		track: "bg-moda-ink/25"
	},
	mediana: {
		band: "bg-mediana text-mediana-ink",
		border: "border-mediana",
		fill: "bg-mediana-ink",
		track: "bg-mediana-ink/25"
	}
};
var TOPICS = [
	{
		id: "barras",
		title: "Gráfica de barras",
		body: "Compara categorías. La barra más alta es la cantidad mayor.",
		figure: {
			kind: "bars",
			values: [
				4,
				9,
				6,
				3
			],
			labels: [
				"Perro",
				"Gato",
				"Ave",
				"Pez"
			]
		}
	},
	{
		id: "circular",
		title: "Gráfica circular",
		body: "Reparte un total en partes. El círculo completo es el 100%.",
		figure: {
			kind: "pie",
			slices: [
				{
					label: "Fútbol",
					value: 10
				},
				{
					label: "Básquet",
					value: 6
				},
				{
					label: "Nado",
					value: 4
				}
			]
		}
	},
	{
		id: "poligono",
		title: "Polígono de frecuencias",
		body: "Une las frecuencias con una línea. El pico es el dato que más se repite.",
		figure: {
			kind: "polygon",
			values: [
				2,
				5,
				8,
				4,
				1
			],
			labels: [
				"0",
				"1",
				"2",
				"3",
				"4"
			]
		}
	},
	{
		id: "rango",
		title: "Rango",
		body: "Dato mayor menos dato menor. Dice qué tan separados están.",
		figure: {
			kind: "chips",
			values: [
				3,
				8,
				1,
				6
			]
		}
	},
	{
		id: "media",
		title: "Media",
		body: "El promedio: suma todos los datos y divide entre cuántos son.",
		figure: {
			kind: "chips",
			values: [
				2,
				4,
				6,
				8
			]
		}
	},
	{
		id: "moda",
		title: "Moda",
		body: "El dato que más veces aparece. Si ninguno se repite, no hay moda.",
		figure: {
			kind: "chips",
			values: [
				5,
				1,
				5,
				5,
				2
			]
		}
	},
	{
		id: "mediana",
		title: "Mediana",
		body: "Ordénalos y toma el del centro. Si sobran dos, promedia esos dos.",
		figure: {
			kind: "chips",
			values: [
				4,
				1,
				7,
				3,
				9
			]
		}
	}
];
var TIERS = [
	{
		min: 1,
		tier: {
			title: "Leyenda de los datos",
			line: "Todo claro: barras, circular, polígono, rango, media, moda y mediana.",
			image: "/memes/legend.jpg",
			alt: "Estudiante celebrando encima de una montaña de papel cuadriculado"
		}
	},
	{
		min: .8,
		tier: {
			title: "Casi profe",
			line: "Te faltó un detallito. Con un repaso corto, el puntaje perfecto está cerca.",
			image: "/memes/crack.jpg",
			alt: "Estudiante con lentes recargado en una recta perfecta"
		}
	},
	{
		min: .6,
		tier: {
			title: "Buen ojo para las gráficas",
			line: "Ya lees las gráficas y calculas con calma. Repasa lo que fallaste y subes.",
			image: "/memes/good.jpg",
			alt: "Estudiante sonriente con el pulgar arriba junto a una curva"
		}
	},
	{
		min: .35,
		tier: {
			title: "Vas calentando",
			line: "Varias ideas ya están. Vuelve a mirar el rango, el promedio y el dato del centro.",
			image: "/memes/warming.jpg",
			alt: "Estudiante pensativo mirando una línea chueca en papel cuadriculado"
		}
	},
	{
		min: 0,
		tier: {
			title: "Hoy los datos ganaron",
			line: "Sin drama: ordena los números, resta el mayor menos el menor y mira la barra más alta.",
			image: "/memes/panic.jpg",
			alt: "Estudiante abrumado entre hojas de planos cartesianos arrugados"
		}
	}
];
function memeFor(score, total) {
	const ratio = total === 0 ? 0 : score / total;
	for (const row of TIERS) if (ratio >= row.min) return row.tier;
	return TIERS[TIERS.length - 1].tier;
}
function topicById(id) {
	return TOPICS.find((topic) => topic.id === id) ?? TOPICS[0];
}
function shuffle(list, rand) {
	const copy = [...list];
	for (let i = copy.length - 1; i > 0; i--) {
		const j = Math.floor(rand() * (i + 1));
		const tmp = copy[i];
		copy[i] = copy[j];
		copy[j] = tmp;
	}
	return copy;
}
function pick(list, rand) {
	return list[Math.floor(rand() * list.length)];
}
function nid(rand) {
	return `q-${Math.floor(rand() * 1e9).toString(36)}`;
}
function sampleDistinct(rand, count, lo = 1, hi = 16) {
	const pool = [];
	for (let n = lo; n <= hi; n++) pool.push(n);
	return shuffle(pool, rand).slice(0, count);
}
function sum(values) {
	return values.reduce((total, value) => total + value, 0);
}
function rangeOf(values) {
	return Math.max(...values) - Math.min(...values);
}
function sortedCopy(values) {
	return [...values].sort((a, b) => a - b);
}
function medianOf(values) {
	const ordered = sortedCopy(values);
	const mid = Math.floor(ordered.length / 2);
	if (ordered.length % 2 === 1) return ordered[mid];
	return (ordered[mid - 1] + ordered[mid]) / 2;
}
function modeOf(values) {
	const counts = /* @__PURE__ */ new Map();
	for (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);
	let best = 0;
	let winner = null;
	let ties = 0;
	for (const [value, count] of counts) if (count > best) {
		best = count;
		winner = value;
		ties = 1;
	} else if (count === best) ties += 1;
	if (best <= 1 || ties > 1) return null;
	return winner;
}
function pack(rand, q) {
	const options = q.items.map((item, index) => ({
		id: item.correct ? "ok" : `w${index}`,
		label: item.label,
		figure: item.figure
	}));
	return {
		id: nid(rand),
		topic: q.topic,
		prompt: q.prompt,
		explain: q.explain,
		figure: q.figure,
		srFigure: q.srFigure,
		options: shuffle(options, rand),
		correctId: "ok"
	};
}
function numericWrongs(correct, pool) {
	const out = [];
	const push = (value) => {
		if (!Number.isInteger(value) || value < 0 || value === correct) return;
		const label = String(value);
		if (out.includes(label)) return;
		out.push(label);
	};
	for (const value of pool) {
		push(value);
		if (out.length === 3) return out;
	}
	let step = 1;
	while (out.length < 3 && step < 20) {
		push(correct + step);
		push(correct - step);
		step += 1;
	}
	return out.slice(0, 3);
}
function distinct(question) {
	const labels = question.options.map((option) => option.label);
	const ids = question.options.map((option) => option.id);
	return question.options.length === 4 && new Set(labels).size === 4 && new Set(ids).size === 4 && question.options.some((option) => option.id === question.correctId);
}
function safe(build, rand) {
	let last = build(rand);
	for (let attempt = 0; attempt < 12 && !distinct(last); attempt++) last = build(rand);
	return last;
}
var BAR_SCENES = [
	{
		thing: "mascota",
		plural: "mascotas",
		labels: [
			"Perro",
			"Gato",
			"Ave",
			"Pez"
		]
	},
	{
		thing: "fruta",
		plural: "frutas",
		labels: [
			"Mango",
			"Pera",
			"Uva",
			"Kiwi"
		]
	},
	{
		thing: "deporte",
		plural: "deportes",
		labels: [
			"Fútbol",
			"Nado",
			"Básquet",
			"Bici"
		]
	},
	{
		thing: "color",
		plural: "colores",
		labels: [
			"Rojo",
			"Azul",
			"Verde",
			"Rosa"
		]
	}
];
function barValues(rand) {
	return shuffle([
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		12
	], rand).slice(0, 4);
}
function barsFigure(labels, values) {
	return {
		kind: "bars",
		values,
		labels: [...labels]
	};
}
function barsHighest(rand) {
	const scene = pick(BAR_SCENES, rand);
	const values = barValues(rand);
	const max = Math.max(...values);
	const winner = scene.labels[values.indexOf(max)];
	return pack(rand, {
		topic: "barras",
		prompt: `En esta gráfica de barras, ¿qué ${scene.thing} eligieron más alumnos?`,
		explain: `Comparas las alturas. La barra más alta es ${winner}, con ${max} alumnos. En la base va la categoría y en la altura, la cantidad.`,
		figure: barsFigure(scene.labels, values),
		srFigure: scene.labels.map((label, index) => `${label}: ${values[index]}`).join(". "),
		items: scene.labels.map((label) => ({
			label,
			correct: label === winner
		}))
	});
}
function barsRead(rand) {
	const scene = pick(BAR_SCENES, rand);
	const values = barValues(rand);
	const index = Math.floor(rand() * values.length);
	const label = scene.labels[index];
	const value = values[index];
	return pack(rand, {
		topic: "barras",
		prompt: `¿Cuántos alumnos eligieron ${label}?`,
		explain: `Busca la barra de ${label} y lee su altura: ${value}. No sumes todas las barras, solo esa.`,
		figure: barsFigure(scene.labels, values),
		srFigure: scene.labels.map((name, i) => `${name}: ${values[i]}`).join(". "),
		items: [{
			label: String(value),
			correct: true
		}, ...numericWrongs(value, values.filter((item) => item !== value).concat([sum(values), maxOf(values)])).map((text) => ({ label: text }))]
	});
}
function maxOf(values) {
	return Math.max(...values);
}
function barsDiff(rand) {
	const scene = pick(BAR_SCENES, rand);
	const values = barValues(rand);
	const order = values.map((value, index) => ({
		value,
		index
	})).sort((a, b) => b.value - a.value);
	const hi = order[0];
	const lo = order[order.length - 1];
	const diff = hi.value - lo.value;
	const a = scene.labels[hi.index];
	const b = scene.labels[lo.index];
	return pack(rand, {
		topic: "barras",
		prompt: `¿Cuántos alumnos más eligieron ${a} que ${b}?`,
		explain: `${a} tiene ${hi.value} y ${b} tiene ${lo.value}. La diferencia es ${hi.value} − ${lo.value} = ${diff}.`,
		figure: barsFigure(scene.labels, values),
		srFigure: scene.labels.map((name, i) => `${name}: ${values[i]}`).join(". "),
		items: [{
			label: String(diff),
			correct: true
		}, ...numericWrongs(diff, [
			hi.value,
			lo.value,
			hi.value + lo.value,
			sum(values)
		]).map((text) => ({ label: text }))]
	});
}
function barsWhen(rand) {
	return pack(rand, {
		topic: "barras",
		prompt: "Quieres comparar cuántos alumnos prefieren cada mascota. ¿Qué gráfica conviene?",
		explain: "La gráfica de barras sirve para comparar categorías lado a lado. La más alta es la preferida. La circular reparte un total y el polígono une frecuencias con una línea.",
		items: [
			{
				label: "Gráfica de barras",
				correct: true
			},
			{ label: "Solo el rango, sin dibujar" },
			{ label: "La mediana, que es un número" },
			{ label: "Una suma, sin categorías" }
		]
	});
}
var PIES = [
	{
		whole: "alumnos",
		labels: [
			"Fútbol",
			"Básquet",
			"Nado"
		],
		values: [
			10,
			6,
			4
		]
	},
	{
		whole: "alumnos",
		labels: [
			"Rojo",
			"Azul",
			"Verde"
		],
		values: [
			12,
			5,
			3
		]
	},
	{
		whole: "votos",
		labels: [
			"Pizza",
			"Tacos",
			"Fruta"
		],
		values: [
			9,
			6,
			3
		]
	},
	{
		whole: "alumnos",
		labels: [
			"Cine",
			"Parque",
			"Casa"
		],
		values: [
			5,
			11,
			4
		]
	},
	{
		whole: "alumnos",
		labels: [
			"Bus",
			"Bici",
			"A pie"
		],
		values: [
			14,
			6,
			4
		]
	},
	{
		whole: "votos",
		labels: [
			"Rock",
			"Pop",
			"Jazz"
		],
		values: [
			8,
			5,
			3
		]
	}
];
function pieFigure(labels, values) {
	return {
		kind: "pie",
		slices: labels.map((label, index) => ({
			label,
			value: values[index]
		}))
	};
}
function pieLargest(rand) {
	const scene = pick(PIES, rand);
	const values = [...scene.values];
	const max = Math.max(...values);
	const winner = scene.labels[values.indexOf(max)];
	return pack(rand, {
		topic: "circular",
		prompt: "En esta gráfica circular, ¿qué parte es la mayor?",
		explain: `La rebanada más grande es ${winner}, con ${max}. En una circular, el círculo completo junta todas las partes.`,
		figure: pieFigure(scene.labels, scene.values),
		srFigure: scene.labels.map((label, index) => `${label}: ${scene.values[index]}`).join(". "),
		items: [...scene.labels.map((label) => ({
			label,
			correct: label === winner
		})), { label: "Las tres iguales" }]
	});
}
function pieTotal(rand) {
	const scene = pick(PIES, rand);
	const total = sum([...scene.values]);
	return pack(rand, {
		topic: "circular",
		prompt: `Si juntas todas las rebanadas, ¿cuántos ${scene.whole} representa el círculo?`,
		explain: `El círculo es el total. ${scene.values.join(" + ")} = ${total}. No te quedes solo con la rebanada más grande.`,
		figure: pieFigure(scene.labels, scene.values),
		srFigure: scene.labels.map((label, index) => `${label}: ${scene.values[index]}`).join(". "),
		items: [{
			label: String(total),
			correct: true
		}, ...numericWrongs(total, [
			maxOf([...scene.values]),
			scene.values[0] + scene.values[1],
			scene.values.length
		]).map((text) => ({ label: text }))]
	});
}
function pieRead(rand) {
	const scene = pick(PIES, rand);
	const index = Math.floor(rand() * scene.labels.length);
	const label = scene.labels[index];
	const value = scene.values[index];
	return pack(rand, {
		topic: "circular",
		prompt: `¿Cuántos corresponden a ${label}?`,
		explain: `En la leyenda, ${label} vale ${value}. Esa es su parte del círculo, no el total.`,
		figure: pieFigure(scene.labels, scene.values),
		srFigure: scene.labels.map((name, i) => `${name}: ${scene.values[i]}`).join(". "),
		items: [{
			label: String(value),
			correct: true
		}, ...numericWrongs(value, [...scene.values, sum([...scene.values])]).map((text) => ({ label: text }))]
	});
}
function pieWhen(rand) {
	return pack(rand, {
		topic: "circular",
		prompt: "Quieres mostrar cómo se reparte un total completo en partes. ¿Qué gráfica conviene?",
		explain: "La gráfica circular, también llamada de pastel, sirve cuando las partes juntas forman un entero. Las barras comparan categorías y el polígono enseña cómo sube o baja la frecuencia.",
		items: [
			{
				label: "Gráfica circular",
				correct: true
			},
			{ label: "Solo el rango" },
			{ label: "La moda, sin dibujo" },
			{ label: "Una resta de dos datos" }
		]
	});
}
var POLYS = [
	{
		axis: "Hermanos",
		labels: [
			"0",
			"1",
			"2",
			"3",
			"4"
		],
		values: [
			2,
			5,
			8,
			4,
			1
		],
		peak: "¿Qué número de hermanos tiene la mayor frecuencia?"
	},
	{
		axis: "Libros",
		labels: [
			"1",
			"2",
			"3",
			"4",
			"5"
		],
		values: [
			3,
			4,
			9,
			6,
			2
		],
		peak: "¿Qué cantidad de libros tiene la mayor frecuencia?"
	},
	{
		axis: "Goles",
		labels: [
			"0",
			"1",
			"2",
			"3"
		],
		values: [
			4,
			7,
			5,
			2
		],
		peak: "¿Qué número de goles tiene la mayor frecuencia?"
	},
	{
		axis: "Nota",
		labels: [
			"6",
			"7",
			"8",
			"9",
			"10"
		],
		values: [
			1,
			4,
			6,
			9,
			3
		],
		peak: "¿Qué nota tiene la mayor frecuencia?"
	}
];
function polyFigure(labels, values) {
	return {
		kind: "polygon",
		values: [...values],
		labels: [...labels]
	};
}
function polyPeak(rand) {
	const scene = pick(POLYS, rand);
	const values = [...scene.values];
	const max = Math.max(...values);
	const winner = scene.labels[values.indexOf(max)];
	const wrongLabels = scene.labels.filter((label) => label !== winner).slice(0, 3);
	return pack(rand, {
		topic: "poligono",
		prompt: scene.peak,
		explain: `En el polígono, el punto más alto es la mayor frecuencia. Está en ${winner}, con frecuencia ${max}.`,
		figure: polyFigure(scene.labels, scene.values),
		srFigure: scene.labels.map((label, index) => `${scene.axis} ${label}: frecuencia ${scene.values[index]}`).join(". "),
		items: [{
			label: winner,
			correct: true
		}, ...wrongLabels.map((label) => ({ label }))]
	});
}
function polyRead(rand) {
	const scene = pick(POLYS, rand);
	const index = Math.floor(rand() * scene.labels.length);
	const label = scene.labels[index];
	const value = scene.values[index];
	return pack(rand, {
		topic: "poligono",
		prompt: `¿Cuál es la frecuencia del dato ${label}?`,
		explain: `El número junto al punto de ${label} es su frecuencia: ${value}. No es la etiqueta del eje, es la altura del punto.`,
		figure: polyFigure(scene.labels, scene.values),
		srFigure: scene.labels.map((name, i) => `${name}: ${scene.values[i]}`).join(". "),
		items: [{
			label: String(value),
			correct: true
		}, ...numericWrongs(value, [
			...scene.values,
			Number(label) || 0,
			sum([...scene.values])
		]).map((text) => ({ label: text }))]
	});
}
function polyDiff(rand) {
	const scene = pick(POLYS, rand);
	const order = scene.values.map((value, index) => ({
		value,
		index
	})).sort((a, b) => b.value - a.value);
	const hi = order[0];
	const lo = order[order.length - 1];
	const diff = hi.value - lo.value;
	return pack(rand, {
		topic: "poligono",
		prompt: `¿En cuánto supera la frecuencia de ${scene.labels[hi.index]} a la de ${scene.labels[lo.index]}?`,
		explain: `Frecuencia de ${scene.labels[hi.index]}: ${hi.value}. Frecuencia de ${scene.labels[lo.index]}: ${lo.value}. Resta: ${hi.value} − ${lo.value} = ${diff}.`,
		figure: polyFigure(scene.labels, scene.values),
		srFigure: scene.labels.map((name, i) => `${name}: ${scene.values[i]}`).join(". "),
		items: [{
			label: String(diff),
			correct: true
		}, ...numericWrongs(diff, [
			hi.value,
			lo.value,
			hi.value + lo.value
		]).map((text) => ({ label: text }))]
	});
}
var SHAPE_ITEMS = [
	{
		label: "Puntos unidos por una línea",
		figure: {
			kind: "polygon",
			values: [
				2,
				6,
				9,
				4,
				3
			],
			labels: [
				"0",
				"1",
				"2",
				"3",
				"4"
			]
		},
		id: "polygon"
	},
	{
		label: "Barras separadas de distinta altura",
		figure: {
			kind: "bars",
			values: [
				4,
				8,
				5,
				2
			],
			labels: [
				"A",
				"B",
				"C",
				"D"
			]
		},
		id: "bars"
	},
	{
		label: "Un círculo partido en rebanadas",
		figure: {
			kind: "pie",
			slices: [
				{
					label: "A",
					value: 5
				},
				{
					label: "B",
					value: 3
				},
				{
					label: "C",
					value: 2
				}
			]
		},
		id: "pie"
	},
	{
		label: "Números sueltos, sin ejes",
		figure: {
			kind: "chips",
			values: [
				4,
				7,
				2,
				9
			]
		},
		id: "chips"
	}
];
function whichPolygon(rand) {
	return pack(rand, {
		topic: "poligono",
		prompt: "¿Cuál figura es un polígono de frecuencias?",
		explain: "El polígono de frecuencias marca cada frecuencia con un punto y los une con segmentos. No son barras sueltas ni un círculo partido.",
		items: SHAPE_ITEMS.map((item) => ({
			label: item.label,
			figure: item.figure,
			correct: item.id === "polygon"
		}))
	});
}
function whichBars(rand) {
	return pack(rand, {
		topic: "barras",
		prompt: "¿Cuál figura es una gráfica de barras?",
		explain: "La gráfica de barras usa rectángulos separados. La altura de cada uno es la cantidad de esa categoría.",
		items: SHAPE_ITEMS.map((item) => ({
			label: item.label,
			figure: item.figure,
			correct: item.id === "bars"
		}))
	});
}
function polyWhat(rand) {
	return pack(rand, {
		topic: "poligono",
		prompt: "¿Qué es un polígono de frecuencias?",
		explain: "Es la línea que une los puntos de las frecuencias, en orden. Así se ve si los datos suben o bajan. No es una resta ni un círculo.",
		figure: {
			kind: "polygon",
			values: [
				1,
				4,
				7,
				5,
				2
			],
			labels: [
				"6",
				"7",
				"8",
				"9",
				"10"
			]
		},
		srFigure: "Polígono con frecuencias 1, 4, 7, 5 y 2.",
		items: [
			{
				label: "Una línea que une las frecuencias de cada dato",
				correct: true
			},
			{ label: "El dato mayor menos el dato menor" },
			{ label: "Un círculo partido en porcentajes" },
			{ label: "Sumar los datos y dividir" }
		]
	});
}
function rangeCalc(rand) {
	const values = sampleDistinct(rand, pick([4, 5], rand));
	const hi = Math.max(...values);
	const lo = Math.min(...values);
	const range = hi - lo;
	return pack(rand, {
		topic: "rango",
		prompt: "¿Cuál es el rango de estos datos?",
		explain: `El rango es el mayor menos el menor: ${hi} − ${lo} = ${range}. No es el mayor solo, ni la cantidad de datos.`,
		figure: {
			kind: "chips",
			values
		},
		srFigure: `Datos: ${values.join(", ")}.`,
		items: [{
			label: String(range),
			correct: true
		}, ...numericWrongs(range, [
			hi,
			lo,
			hi + lo,
			values.length,
			sortedCopy(values)[1]
		]).map((text) => ({ label: text }))]
	});
}
function rangeKnown(rand) {
	const lo = pick([
		0,
		1,
		2,
		3,
		4
	], rand);
	const range = pick([
		5,
		6,
		7,
		8,
		9,
		12
	], rand);
	const hi = lo + range;
	return pack(rand, {
		topic: "rango",
		prompt: `El dato mayor es ${hi} y el menor es ${lo}. ¿Cuál es el rango?`,
		explain: `Rango = mayor − menor = ${hi} − ${lo} = ${range}.`,
		items: [{
			label: String(range),
			correct: true
		}, ...numericWrongs(range, [
			hi,
			lo,
			hi + lo,
			hi - lo + 1
		]).map((text) => ({ label: text }))]
	});
}
function rangeCompare(rand) {
	const a = sampleDistinct(rand, 4);
	let b = sampleDistinct(rand, 4);
	for (let attempt = 0; attempt < 6 && rangeOf(a) === rangeOf(b); attempt++) b = sampleDistinct(rand, 4);
	const ra = rangeOf(a);
	const rb = rangeOf(b);
	const correct = ra === rb ? "Empate: el mismo rango" : ra > rb ? "El grupo A" : "El grupo B";
	return pack(rand, {
		topic: "rango",
		prompt: `Grupo A: ${a.join(", ")}. Grupo B: ${b.join(", ")}. ¿Qué grupo tiene mayor rango?`,
		explain: `A: ${Math.max(...a)} − ${Math.min(...a)} = ${ra}. B: ${Math.max(...b)} − ${Math.min(...b)} = ${rb}. ${ra === rb ? "Quedan iguales." : ra > rb ? "A es mayor." : "B es mayor."}`,
		items: [
			"El grupo A",
			"El grupo B",
			"Empate: el mismo rango",
			"No se puede saber"
		].map((label) => ({
			label,
			correct: label === correct
		}))
	});
}
function rangeWhat(rand) {
	return pack(rand, {
		topic: "rango",
		prompt: "¿Cómo se calcula el rango?",
		explain: "Se resta el dato menor al dato mayor. Si los datos son 2, 9 y 5, el rango es 9 − 2 = 7. No hace falta ordenarlos todos, solo ubicar el mayor y el menor.",
		items: [
			{
				label: "Dato mayor menos dato menor",
				correct: true
			},
			{ label: "Sumar todo y dividir entre cuántos hay" },
			{ label: "Elegir el dato que más se repite" },
			{ label: "Tomar el dato que queda en el centro" }
		]
	});
}
var MEAN_SETS = [
	[
		2,
		4,
		6,
		8
	],
	[
		1,
		3,
		5,
		7
	],
	[
		5,
		5,
		5,
		5
	],
	[
		2,
		2,
		5,
		7
	],
	[
		1,
		2,
		3,
		6
	],
	[
		4,
		6,
		8,
		10
	],
	[
		3,
		3,
		6,
		8
	],
	[
		2,
		3,
		4,
		5,
		6
	],
	[
		1,
		1,
		4,
		6,
		8
	],
	[
		10,
		12,
		14
	],
	[
		6,
		8,
		10
	],
	[
		1,
		5,
		9
	],
	[
		4,
		4,
		4,
		8
	],
	[
		3,
		6,
		6,
		9
	],
	[
		1,
		2,
		3,
		4,
		10
	],
	[
		4,
		5,
		6
	],
	[
		8,
		8,
		11,
		13
	],
	[
		2,
		4,
		4,
		6,
		9
	]
];
function meanCalc(rand) {
	const values = pick(MEAN_SETS, rand);
	const total = sum(values);
	const mean = total / values.length;
	return pack(rand, {
		topic: "media",
		prompt: "¿Cuál es la media (el promedio) de estos datos?",
		explain: `Suma: ${values.join(" + ")} = ${total}. Hay ${values.length} datos. Media = ${total} ÷ ${values.length} = ${mean}.`,
		figure: {
			kind: "chips",
			values
		},
		srFigure: `Datos: ${values.join(", ")}.`,
		items: [{
			label: String(mean),
			correct: true
		}, ...numericWrongs(mean, [
			total,
			maxOf(values),
			Math.min(...values),
			values.length,
			mean + values.length
		]).map((text) => ({ label: text }))]
	});
}
var MEAN_SUMS = [
	{
		sum: 20,
		n: 4,
		mean: 5
	},
	{
		sum: 18,
		n: 6,
		mean: 3
	},
	{
		sum: 24,
		n: 4,
		mean: 6
	},
	{
		sum: 15,
		n: 5,
		mean: 3
	},
	{
		sum: 30,
		n: 5,
		mean: 6
	},
	{
		sum: 12,
		n: 3,
		mean: 4
	},
	{
		sum: 36,
		n: 6,
		mean: 6
	},
	{
		sum: 21,
		n: 7,
		mean: 3
	},
	{
		sum: 40,
		n: 8,
		mean: 5
	},
	{
		sum: 27,
		n: 3,
		mean: 9
	}
];
function meanFromSum(rand) {
	const row = pick(MEAN_SUMS, rand);
	return pack(rand, {
		topic: "media",
		prompt: `La suma de los datos es ${row.sum} y hay ${row.n} datos. ¿Cuál es la media?`,
		explain: `Media = suma ÷ cantidad = ${row.sum} ÷ ${row.n} = ${row.mean}.`,
		items: [{
			label: String(row.mean),
			correct: true
		}, ...numericWrongs(row.mean, [
			row.sum,
			row.n,
			row.sum - row.n,
			row.mean + row.n
		]).map((text) => ({ label: text }))]
	});
}
function meanWhat(rand) {
	return pack(rand, {
		topic: "media",
		prompt: "¿Qué es la media aritmética?",
		explain: "La media, o promedio, se obtiene sumando todos los datos y dividiendo entre cuántos datos hay. No es el que más se repite ni el del centro.",
		items: [
			{
				label: "La suma de los datos dividida entre cuántos son",
				correct: true
			},
			{ label: "El dato que más se repite" },
			{ label: "El dato del centro, ya ordenados" },
			{ label: "El dato mayor menos el menor" }
		]
	});
}
var MODE_SETS = [
	[
		3,
		5,
		5,
		5,
		8
	],
	[
		2,
		2,
		4,
		7,
		9
	],
	[
		6,
		1,
		6,
		4,
		3
	],
	[
		8,
		8,
		8,
		2,
		5
	],
	[
		4,
		9,
		4,
		1,
		7
	],
	[
		1,
		3,
		3,
		3,
		6
	],
	[
		7,
		2,
		7,
		5,
		9
	],
	[
		10,
		10,
		4,
		6
	],
	[
		4,
		4,
		2,
		9,
		1
	],
	[
		6,
		8,
		6,
		6,
		3
	]
];
function modeCalc(rand) {
	const values = pick(MODE_SETS, rand);
	const mode = modeOf(values) ?? values[0];
	const times = values.filter((value) => value === mode).length;
	return pack(rand, {
		topic: "moda",
		prompt: "¿Cuál es la moda de estos datos?",
		explain: `La moda es el dato que más se repite. El ${mode} aparece ${times} veces, más que los demás.`,
		figure: {
			kind: "chips",
			values
		},
		srFigure: `Datos: ${values.join(", ")}.`,
		items: [{
			label: String(mode),
			correct: true
		}, ...numericWrongs(mode, values.filter((value) => value !== mode).concat([sum(values), medianOf(values)])).map((text) => ({ label: text }))]
	});
}
var NO_MODE = [
	[
		1,
		2,
		3,
		4,
		5
	],
	[
		2,
		4,
		6,
		8
	],
	[
		3,
		5,
		7,
		9,
		11
	],
	[
		1,
		4,
		6,
		8,
		10
	],
	[
		2,
		5,
		7,
		9
	]
];
function modeNone(rand) {
	const values = pick(NO_MODE, rand);
	const decoys = values.slice(0, 3).map((value) => `La moda es ${value}`);
	return pack(rand, {
		topic: "moda",
		prompt: "¿Cuál es la moda de estos datos?",
		explain: "Ningún dato se repite: cada uno aparece una sola vez. En ese caso se dice que no hay moda.",
		figure: {
			kind: "chips",
			values
		},
		srFigure: `Datos sin repeticiones: ${values.join(", ")}.`,
		items: [{
			label: "No hay moda",
			correct: true
		}, ...decoys.map((label) => ({ label }))]
	});
}
var MODE_TABLES = [
	{
		headers: ["Color", "Frecuencia"],
		rows: [
			["Rojo", "2"],
			["Azul", "6"],
			["Verde", "3"],
			["Rosa", "1"]
		],
		mode: "Azul",
		freq: "6"
	},
	{
		headers: ["Mascota", "Frecuencia"],
		rows: [
			["Perro", "4"],
			["Gato", "9"],
			["Ave", "5"],
			["Pez", "2"]
		],
		mode: "Gato",
		freq: "9"
	},
	{
		headers: ["Nota", "Frecuencia"],
		rows: [
			["7", "3"],
			["8", "5"],
			["9", "8"],
			["10", "4"]
		],
		mode: "9",
		freq: "8"
	},
	{
		headers: ["Deporte", "Frecuencia"],
		rows: [
			["Fútbol", "7"],
			["Nado", "3"],
			["Básquet", "5"],
			["Bici", "1"]
		],
		mode: "Fútbol",
		freq: "7"
	}
];
function modeFromTable(rand) {
	const table = pick(MODE_TABLES, rand);
	return pack(rand, {
		topic: "moda",
		prompt: "En esta tabla de frecuencias, ¿cuál es la moda?",
		explain: `La moda es el dato con mayor frecuencia. ${table.mode} tiene frecuencia ${table.freq}, la más alta de la tabla.`,
		figure: {
			kind: "table",
			headers: table.headers,
			rows: table.rows
		},
		srFigure: table.rows.map((row) => `${row[0]}: ${row[1]}`).join(". "),
		items: table.rows.map((row) => ({
			label: row[0],
			correct: row[0] === table.mode
		}))
	});
}
function modeWhat(rand) {
	return pack(rand, {
		topic: "moda",
		prompt: "¿Qué es la moda?",
		explain: "La moda es el dato que más veces aparece. En una gráfica de barras o en un polígono, es el de la barra o el punto más alto. Si nadie se repite, no hay moda.",
		items: [
			{
				label: "El dato que más se repite",
				correct: true
			},
			{ label: "La suma dividida entre la cantidad" },
			{ label: "El dato del centro al ordenar" },
			{ label: "El mayor menos el menor" }
		]
	});
}
function modeFromBars(rand) {
	const scene = pick(BAR_SCENES, rand);
	const values = barValues(rand);
	const max = Math.max(...values);
	const winner = scene.labels[values.indexOf(max)];
	return pack(rand, {
		topic: "moda",
		prompt: "Mirando la gráfica, ¿cuál es la moda?",
		explain: `La moda es la categoría que más se repite. Aquí es la barra más alta: ${winner}, con ${max}.`,
		figure: barsFigure(scene.labels, values),
		srFigure: scene.labels.map((label, index) => `${label}: ${values[index]}`).join(". "),
		items: scene.labels.map((label) => ({
			label,
			correct: label === winner
		}))
	});
}
var MEDIAN_ODD = [
	[
		7,
		1,
		4,
		9,
		3
	],
	[
		8,
		2,
		5
	],
	[
		10,
		4,
		6,
		2,
		8
	],
	[
		9,
		1,
		5,
		3,
		7
	],
	[
		12,
		3,
		6,
		15,
		9
	],
	[
		4,
		4,
		4,
		8,
		10
	],
	[
		2,
		9,
		2,
		5,
		2
	],
	[
		1,
		8,
		3,
		6,
		5
	],
	[
		14,
		2,
		8,
		6,
		20
	],
	[
		3,
		11,
		7,
		1,
		5
	]
];
function medianOdd(rand) {
	const values = pick(MEDIAN_ODD, rand);
	const ordered = sortedCopy(values);
	const median = medianOf(values);
	return pack(rand, {
		topic: "mediana",
		prompt: "¿Cuál es la mediana? Acuérdate de ordenar primero.",
		explain: `Ordenados de menor a mayor: ${ordered.join(", ")}. Como hay ${values.length} datos, el del centro es ${median}.`,
		figure: {
			kind: "chips",
			values
		},
		srFigure: `Datos, todavía sin ordenar: ${values.join(", ")}.`,
		items: [{
			label: String(median),
			correct: true
		}, ...numericWrongs(median, [
			...ordered,
			sum(values) / values.length,
			values[0]
		]).map((text) => ({ label: text }))]
	});
}
var MEDIAN_EVEN = [
	[
		1,
		2,
		4,
		5
	],
	[
		2,
		4,
		6,
		10
	],
	[
		1,
		3,
		5,
		7
	],
	[
		3,
		5,
		7,
		9
	],
	[
		2,
		6,
		8,
		12
	],
	[
		4,
		4,
		8,
		10
	],
	[
		1,
		5,
		5,
		9
	],
	[
		2,
		3,
		7,
		8
	],
	[
		5,
		1,
		7,
		9
	],
	[
		8,
		2,
		4,
		6
	]
];
function medianEven(rand) {
	const values = pick(MEDIAN_EVEN, rand);
	const ordered = sortedCopy(values);
	const left = ordered[ordered.length / 2 - 1];
	const right = ordered[ordered.length / 2];
	const median = (left + right) / 2;
	return pack(rand, {
		topic: "mediana",
		prompt: "Hay un número par de datos. ¿Cuál es la mediana?",
		explain: `Ordenados: ${ordered.join(", ")}. En el centro quedan ${left} y ${right}. Mediana = (${left} + ${right}) ÷ 2 = ${median}.`,
		figure: {
			kind: "chips",
			values
		},
		srFigure: `Datos: ${values.join(", ")}.`,
		items: [{
			label: String(median),
			correct: true
		}, ...numericWrongs(median, [
			left,
			right,
			ordered[0],
			ordered[ordered.length - 1],
			left + right
		]).map((text) => ({ label: text }))]
	});
}
function medianWhat(rand) {
	return pack(rand, {
		topic: "mediana",
		prompt: "¿Qué hay que hacer para hallar la mediana?",
		explain: "Primero se ordenan los datos de menor a mayor. Si la cantidad es impar, la mediana es el del centro. Si es par, se promedian los dos que quedan en el centro.",
		items: [
			{
				label: "Ordenar y tomar el dato del centro",
				correct: true
			},
			{ label: "Sumar y dividir entre la cantidad" },
			{ label: "Restar el menor al mayor" },
			{ label: "Elegir el que más se repite" }
		]
	});
}
function medianSpot(rand) {
	const ordered = [
		2,
		5,
		6,
		9,
		11
	];
	return pack(rand, {
		topic: "mediana",
		prompt: `Los datos ordenados quedan ${ordered.join(", ")}. ¿Cuál número es la mediana?`,
		explain: "Son 5 datos. El del centro, el tercero, es 6. El 2 es el menor y el 11 es el mayor: ninguno de esos es la mediana.",
		figure: {
			kind: "chips",
			values: ordered
		},
		srFigure: `Datos ordenados: ${ordered.join(", ")}.`,
		items: [
			{
				label: "6",
				correct: true
			},
			{ label: "2" },
			{ label: "11" },
			{ label: "5" }
		]
	});
}
var BUILDERS = {
	barras: [
		barsHighest,
		barsRead,
		barsDiff,
		barsWhen,
		whichBars
	],
	circular: [
		pieLargest,
		pieTotal,
		pieRead,
		pieWhen
	],
	poligono: [
		polyPeak,
		polyRead,
		polyDiff,
		whichPolygon,
		polyWhat
	],
	rango: [
		rangeCalc,
		rangeKnown,
		rangeCompare,
		rangeWhat
	],
	media: [
		meanCalc,
		meanFromSum,
		meanWhat
	],
	moda: [
		modeCalc,
		modeNone,
		modeFromTable,
		modeWhat,
		modeFromBars
	],
	mediana: [
		medianOdd,
		medianEven,
		medianWhat,
		medianSpot
	]
};
function takeQuestions(builders, count, rand) {
	const made = [];
	const seen = /* @__PURE__ */ new Set();
	let guard = 0;
	let cursor = [];
	while (made.length < count && guard < 40) {
		guard += 1;
		if (cursor.length === 0) cursor = shuffle(builders, rand);
		const build = cursor.pop();
		if (!build) break;
		const question = safe(build, rand);
		const key = `${question.prompt}::${question.options.map((option) => option.label).join("~")}`;
		if (seen.has(key)) continue;
		seen.add(key);
		made.push(question);
	}
	return made;
}
function buildTopicQuiz(topic, rand = Math.random, count = 5) {
	return takeQuestions(BUILDERS[topic], count, rand);
}
function buildQuiz(rand = Math.random) {
	const extra = pick(TOPIC_IDS, rand);
	const ids = shuffle([...TOPIC_IDS, extra], rand);
	const seen = /* @__PURE__ */ new Set();
	return ids.map((id) => {
		let question = safe(pick(BUILDERS[id], rand), rand);
		for (let attempt = 0; attempt < 8 && seen.has(question.prompt); attempt++) question = safe(pick(BUILDERS[id], rand), rand);
		seen.add(question.prompt);
		return question;
	});
}
function scoreQuiz(questions, answers) {
	return questions.filter((question) => answers[question.id] === question.correctId).length;
}
var STORAGE_KEY = "grafiquiz-v2";
var ICONS = {
	barras: ChartColumn,
	circular: ChartPie,
	poligono: ChartLine,
	rango: ArrowLeftRight,
	media: Sigma,
	moda: Star,
	mediana: AlignCenter
};
function loadSave() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (typeof parsed.best !== "number") return null;
		return {
			name: typeof parsed.name === "string" ? parsed.name : "",
			best: parsed.best
		};
	} catch {
		return null;
	}
}
function storeSave(save) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
}
function QuizApp() {
	const [name, setName] = (0, import_react.useState)("");
	const [best, setBest] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("home");
	const [mix, setMix] = (0, import_react.useState)(true);
	const [questions, setQuestions] = (0, import_react.useState)([]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [confirmed, setConfirmed] = (0, import_react.useState)(false);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [record, setRecord] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = loadSave();
		if (saved) {
			setBest(saved.best);
			setName(saved.name);
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	}, [phase, index]);
	function start(topic) {
		const clean = name.trim().slice(0, 24);
		setName(clean);
		setMix(!topic);
		setQuestions(topic ? buildTopicQuiz(topic) : buildQuiz());
		setIndex(0);
		setPicked(null);
		setConfirmed(false);
		setAnswers({});
		setRecord(false);
		setPhase("play");
		const previous = loadSave();
		if (previous) storeSave({
			name: clean,
			best: previous.best
		});
	}
	function confirm() {
		const question = questions[index];
		if (!question || !picked) return;
		setAnswers((current) => ({
			...current,
			[question.id]: picked
		}));
		setConfirmed(true);
	}
	function finish(nextAnswers) {
		const score = scoreQuiz(questions, nextAnswers);
		if (mix) {
			const improved = best !== null && score > best;
			const nextBest = Math.max(best ?? 0, score);
			setBest(nextBest);
			setRecord(improved);
			storeSave({
				name: name.trim(),
				best: nextBest
			});
		}
		setPhase("done");
	}
	function next() {
		if (index + 1 >= questions.length) {
			finish(answers);
			return;
		}
		setIndex((current) => current + 1);
		setPicked(null);
		setConfirmed(false);
	}
	const score = scoreQuiz(questions, answers);
	const meme = memeFor(score, questions.length);
	const missed = questions.filter((question) => answers[question.id] !== question.correctId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPhase("home"),
					className: "flex items-center gap-2 rounded-full bg-sheet px-3 py-2 text-left text-ink ring-1 ring-line",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center rounded-full bg-accent text-accent-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, {
							size: 18,
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-lg leading-none",
						children: "GrafiQuiz"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: "1º de secundaria"
					})] })]
				}), ready && best !== null && best > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-full bg-sheet px-3 py-2 text-sm font-semibold text-ink tabular-nums ring-1 ring-line",
					children: [
						"Mejor ",
						best,
						"/",
						8
					]
				})]
			}),
			phase === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {
				name,
				best: ready ? best : null,
				onName: setName,
				onStart: start
			}),
			phase === "play" && questions[index] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayScreen, {
				question: questions[index],
				index,
				total: questions.length,
				picked,
				confirmed,
				onPick: setPicked,
				onConfirm: confirm,
				onNext: next
			}),
			phase === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultScreen, {
				name: name.trim(),
				score,
				total: questions.length,
				mix,
				meme,
				record,
				missed,
				answers,
				onAgain: () => start(mix ? void 0 : questions[0]?.topic),
				onHome: () => setPhase("home")
			})
		]
	});
}
function HomeScreen({ name, best, onName, onStart }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-3xl bg-accent p-6 text-accent-ink shadow-sm sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tracking-wide uppercase",
					children: "Siete temas, siete colores"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl leading-tight sm:text-5xl",
					children: "Gráficas y promedios"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-prose",
					children: "Preguntas de 1º: barras, gráfica circular, polígono de frecuencias, rango, media, moda y mediana. Cada intento trae datos nuevos."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 flex flex-col gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						onStart();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm font-semibold",
							htmlFor: "student-name",
							children: "Tu nombre, si quieres"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "student-name",
							value: name,
							maxLength: 24,
							autoComplete: "nickname",
							placeholder: "Ejemplo: Ana",
							onChange: (event) => onName(event.target.value),
							className: "min-h-12 w-full rounded-2xl border-2 border-paper bg-paper px-4 text-ink placeholder:text-muted"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							className: "mt-1 inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-paper px-6 font-semibold text-ink",
							children: [
								"Cuestionario de los ",
								TOPIC_IDS.length,
								" temas",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									size: 18,
									"aria-hidden": "true"
								})
							]
						}),
						best !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"Tu mejor marca del cuestionario completo, en este aparato:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold tabular-nums",
									children: [
										best,
										"/",
										8
									]
								})
							]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-ink",
				children: "Elige un tema"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [5, " preguntas del color que pulses. Sirve para repasar uno solo."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2",
				children: TOPICS.map((topic) => {
					const tone = TONES[topic.id];
					const Icon = ICONS[topic.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "button",
						tabIndex: 0,
						onClick: () => onStart(topic.id),
						onKeyDown: (event) => {
							if (event.key === "Enter" || event.key === " ") {
								event.preventDefault();
								onStart(topic.id);
							}
						},
						className: `flex h-full flex-col rounded-3xl p-4 text-left ${tone.band}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-9 shrink-0 items-center justify-center rounded-full bg-paper text-ink",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										size: 18,
										"aria-hidden": "true"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-2xl leading-tight",
									children: topic.title
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-3 block rounded-2xl bg-well p-1 text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraphFigure, {
									figure: topic.figure,
									variant: "mini"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-3 text-sm",
								children: topic.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-3 text-sm font-semibold",
								children: "Practicar este tema"
							})
						]
					}) }, topic.id);
				})
			})
		] })]
	});
}
function PlayScreen({ question, index, total, picked, confirmed, onPick, onConfirm, onNext }) {
	const tone = TONES[question.topic];
	const topic = topicById(question.topic);
	const visual = question.options.some((option) => option.figure);
	const correct = picked === question.correctId;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `rounded-3xl p-5 shadow-sm sm:p-7 ${tone.band}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold tabular-nums",
					children: [
						"Pregunta ",
						index + 1,
						" de ",
						total
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-paper px-3 py-1 font-semibold text-ink",
					children: topic.title
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-3 h-2 overflow-hidden rounded-full ${tone.track}`,
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `h-full rounded-full ${tone.fill}`,
					style: { width: `${index / total * 100}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 font-display text-2xl leading-snug sm:text-3xl",
				children: question.prompt
			}),
			question.srFigure && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				children: question.srFigure
			}),
			question.figure && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mt-4 max-w-md rounded-2xl bg-well p-2 text-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraphFigure, { figure: question.figure })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: visual ? "mt-5 grid grid-cols-2 gap-3" : "mt-5 flex flex-col gap-3",
				role: "group",
				"aria-label": "Opciones",
				children: question.options.map((option) => {
					const isPicked = picked === option.id;
					const showCorrect = confirmed && option.id === question.correctId;
					const showWrong = confirmed && isPicked && option.id !== question.correctId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: confirmed,
						"aria-pressed": isPicked,
						onClick: () => onPick(option.id),
						className: [
							"min-h-12 rounded-2xl border-2 px-3 py-3 text-left text-ink",
							visual ? "flex flex-col gap-2" : "",
							showCorrect ? "border-good bg-good-soft" : showWrong ? "border-bad bg-bad-soft" : isPicked ? "border-accent bg-sheet" : "border-transparent bg-paper",
							confirmed && !showCorrect && !showWrong ? "opacity-55" : ""
						].join(" "),
						children: [option.figure && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block rounded-xl bg-well p-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraphFigure, {
								figure: option.figure,
								variant: "mini"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: option.figure ? "text-sm font-medium" : "font-medium",
							children: option.label
						})]
					}, option.id);
				})
			}),
			confirmed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-2xl bg-paper px-4 py-3 text-sm text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: correct ? "font-semibold text-good" : "font-semibold text-bad",
					children: correct ? "Correcto" : "Casi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: question.explain
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: !confirmed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !picked,
					onClick: onConfirm,
					className: "inline-flex min-h-12 w-full items-center justify-center rounded-full bg-paper px-6 font-semibold text-ink disabled:opacity-40",
					children: "Confirmar respuesta"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onNext,
					className: "inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-paper px-6 font-semibold text-ink",
					children: [index + 1 === total ? "Ver mi puntaje" : "Siguiente", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						size: 18,
						"aria-hidden": "true"
					})]
				})
			})
		]
	});
}
function ResultScreen({ name, score, total, mix, meme, record, missed, answers, onAgain, onHome }) {
	const percent = total === 0 ? 0 : Math.round(score / total * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl bg-sheet p-5 text-ink ring-1 ring-line sm:p-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-accent",
					children: "Resultado"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-3xl",
					children: name ? `${name}, ${meme.title.toLowerCase()}` : meme.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-display text-6xl text-accent tabular-nums leading-none",
					children: [score, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-3xl text-muted",
						children: ["/", total]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted tabular-nums",
					children: [percent, "% de aciertos"]
				}),
				record && score > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 inline-flex items-center gap-2 rounded-full bg-good-soft px-3 py-1 text-sm font-semibold text-good",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, {
						size: 16,
						"aria-hidden": "true"
					}), "Nueva mejor marca"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: meme.image,
					alt: meme.alt,
					width: 960,
					height: 960,
					className: "mt-5 aspect-square w-full rounded-3xl object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg",
					children: meme.line
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onAgain,
						className: "inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-full bg-accent px-5 font-semibold text-accent-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							size: 18,
							"aria-hidden": "true"
						}), mix ? "Otro cuestionario" : "Repetir este tema"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onHome,
						className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-full bg-paper px-5 font-semibold text-ink ring-1 ring-line",
						children: "Elegir tema"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl bg-sheet p-5 text-ink ring-1 ring-line sm:p-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-2xl",
				children: missed.length === 0 ? "No fallaste ninguna" : "Para repasar"
			}), missed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Estas ideas quedaron claras. Si quieres, mezcla otro intento."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-4",
				children: missed.map((question) => {
					const chosen = question.options.find((option) => option.id === answers[question.id]);
					const right = question.options.find((option) => option.id === question.correctId);
					const tone = TONES[question.topic];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-line pt-4 first:border-t-0 first:pt-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `inline-flex rounded-full px-2 py-0.5 text-xs font-semibold ${tone.band}`,
								children: topicById(question.topic).title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-medium",
								children: question.prompt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-bad",
								children: ["Elegiste: ", chosen?.label ?? "sin respuesta"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-good",
								children: ["Correcta: ", right?.label]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: question.explain
							})
						]
					}, question.id);
				})
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizApp, {});
}
//#endregion
export { Home as component };
