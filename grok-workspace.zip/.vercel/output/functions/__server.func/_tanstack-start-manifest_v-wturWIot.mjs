//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-wturWIot.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-_PEl4vjh.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-_PEl4vjh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CAv2uY6d.js"]
	}
} });
//#endregion
export { tsrStartManifest };
